use dotinstall_db;

insert into users (name, score) values ('田中一郎',28);
insert into users (name, score) values ('佐藤次郎',56);
insert into users (name, score) values ('saint john',68);

select * from users;
