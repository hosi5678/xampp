<?php

// phpinfo();

$a=3;
$b=2;

$c=$a+$b;

var_dump($c);