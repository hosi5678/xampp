<?php
require("./libs/session.php");
require("./libs/escape_string.php");
require("./libs/ip_address.php");
require("./libs/ip_address_check.php");
require("./libs/insert_access_log.php");

// 外部からの命令を無効化
$ip_address_ext=escape_string($_SERVER["REMOTE_ADDR"]);

// ipアドレスをチェック
$flag=ip_address_check($ip_address_ext);

// アクセスログ(簡易版)テーブルに書き込み
insert_access_log($ip_address_ext,$flag);

?>

<!doctype html>

<html lang="ja">

<head>
<meta charset="utf-8">
<title>おりなすデータベースホームページ</title>
	<link rel="stylesheet" type="text/css" href="./css/index.css">
	<link href="./css/jquery-ui.min.css" rel="stylesheet">
	<script src="./js/jquery-3.4.1.min.js"></script>
	<script src="./js/jquery-ui.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>
</head>

<script type="text/javascript" src="./js/getpassword.js"></script>
<script type="text/javascript" src="./js/getipaddress.js"></script>

<body>

<h1>ログイン</h1>

<hr>

<form action="./other_pages/menu.php" method="post" name="form1">
	
<table>
	<tr>
		<td><input type="radio" class="radio" name="id" value="1"></td>
		<td>管理者 ログイン(アクセスログ閲覧用)</td>
	</tr>
	<tr>
		<td><input type="radio" class="radio" name="id" value="2" checked></td>
		<td>ユーザ ログイン</td>
	</tr>
</table>
	<button>ログイン</button></form>

</body>

</html>