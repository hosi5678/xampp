<?php

require("../libs/session.php");
require("../libs/escape_string.php");
require("../libs/is_empty.php");

$id_ext=escape_string($_POST["id"]);
is_empty($id_ext);

$_SESSION["id"]=$id_ext;

	if($id_ext==='1'){
//		echo 'orinasu_admin';
		$title='管理画面';

		$links ='<a href="#" onclick="ajax_select_from_staffs();">スタッフ一覧</a>';
		$links.='<br>';
		$links.='<br>';
		$links.='<a href="#" onclick="ajax_select_from_users();">利用者一覧</a>';
		$links.='<br>';
		$links.='<a href="#" onclick="add_user();ajax_add_uer()">新規利用者登録</a>';
		$links.='<br>';
		$links.='<a href="#" onclick="ajax_delete_user();">利用者削除</a>';

	}else if($id_ext==='2'){
		$title='一般画面';
		$links='<a href="../other_pages/select_users.php">棚卸し表</a>';
	}

	$back='<a href="../index.php">ログイン画面へ戻る</a>';

?>

<!doctype html>

<html lang="ja">

<head>
<meta charset="utf-8">
<title>おりなすデータベース</title>
	<link rel="stylesheet" type="text/css" href="./css/menu.css">
	<link rel="stylesheet" type="text/css" href="../css/jquery-ui.min.css">
	<script type="text/javascript" src="../js/jquery-3.4.1.min.js"></script>
	<script type="text/javascript" src="../js/jquery-ui.min.js"></script>
	<script src="./js/ajax_select_from_users.js"></script>
	<script src="./js/ajax_select_from_staffs.js"></script>
	<script src="./js/add_user.js"></script>
	<script src="./js/add_staff.js"></script>
	<script src="./js/ajax_insert_into_users.js"></script>
	<script src="./js/ajax_insert_into_staffs.js"></script>
</head>

<body>

<!--
<div id='resizable' class="ui-widget-content">
-->

<header>
	<article>
		<?php echo $title; ?>
	</article>

	<article>
		<?php echo $back; ?>
	</article>
</header>

	<nav>
		<article><?php echo $links ?></article>
		<article>リンク2</article>
		<article>リンク3</article>
	</nav>

	<main>
		
		<div id="param">
		</div>

		<div id="result">
		</div>

	</main>

<!--
	<aside>
		<article>補足1</article>
		<article>補足2</article>
		<article>補足3</article>
	</aside>
-->

	<footer>メッセージ</footer>

<!--
</div>
-->

</body>

</html>