function ajax_update_members_set_where(id){

			member_surname=$('#member_surname').val();
			member_name=$('#member_name').val();
			start_date=$('#start_date').val();
/*		
			member_surname=$('#member_surname').val();
			member_name=$('#member_name').val();
			start_date=$('#start_date').val();
*/			
	console.log('in update js');
										console.log(id);
							console.log(member_surname);
							console.log(member_name);
							console.log(start_date);
		
	$.post({
		url: '../../libs/ajax_update_members_set_where.php',
		data:{
				'id':id,
				'member_surname':member_surname,
				'member_name':member_name,
				'start_date':start_date
		},
		dataType:'json' //'json', 
       }).done(function(data){

			create_members_table(data);
				
        }).fail(function(XMLHttpRequest,textStatus,errorThrown){
        	console.log(XMLHttpRequest);
        	console.log(textStatus);
         	console.log(errorThrown);
        })

}