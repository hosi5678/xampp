function about_staffs(){

	common_change_borders();

	ajax_select_from_staffs();

}