function ajax_insert_into_members(){
//       var id = $('input[name="id"]:checked').val();

			member_surname=$('#member_surname').val();
			member_name=$('#member_name').val();
			start_date=$('#start_date').val();
			
			// console.log(start_date);

			$.post({
				url: '../../libs/ajax_insert_into_members.php',
		      data:{
					'member_surname': member_surname,
					'member_name': member_name,
					'start_date': start_date
				},

			dataType:'json' //'json', 

        }).done(function(data){

			create_members_table(data,1);
				
        }).fail(function(XMLHttpRequest,textStatus,errorThrown){
        	console.log(XMLHttpRequest);
        	console.log(textStatus);
 	        console.log(errorThrown);
        })
    
}
