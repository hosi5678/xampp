use mysql;
alter user root@localhost identified by 'password';