create table users(
	id int unsigned,
	name varchar(20),
	score float

);
