function test(){

    var a=3;
    var b=2;

    var c=a+b;

    console.log(c);

}