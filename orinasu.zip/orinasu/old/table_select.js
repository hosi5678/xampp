function table_select(){
        // $('#tblPlanSpot1 td').live('click',function(){
        //     var $cur_td = $(this)[0]; // (1):セルのHTML表現 [0]をつける点に留意のこと。  
        //     var $cur_tr = $(this).parent()[0]; // (2):行のHTML表現

            
        //     //
        //     // $cur_tr = $(this).closest('tr')[0]; // このほうが確実
        // });

        var id=document.getElementById('tblPlanSpot1');

        console.log(id);
}