'use strict';
function create_h_calendar({		
  parent_tag_str,
  table_name,
  year,
  month,
  date,
  youbi,
}){

  console.log('--- in create h calendar ---');
	console.log(year);
	console.log(month);
	console.log(date);
	console.log(youbi);


}