function common_change_borders(){

	document.getElementById("main").style.height='700px';
	document.getElementById("nav").style.height='700px';
	document.getElementById("message").style.height='0px';
	document.getElementById("message").innerHTML='';

// param+result=700px
	document.getElementById("param").style.height='350px';
	document.getElementById("result").style.height='350px';

}
