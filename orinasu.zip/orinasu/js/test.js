function test(event){

  // console.log(event.target.prev);

  var input=document.createElement('input');

  var div=document.getElementById("select");

  var a=document.createElement('button');

  a.innerText='クリックする';

  // a.href='#';

  a.addEventListener('click',function (event) {
      input.value='test';

    });

   div.appendChild(input);
   div.appendChild(a); 


}