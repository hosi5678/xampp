function create_calendar(event){

 console.log('in create calendar');
 console.log(event.target.youbi);
 console.log(this.selectedIndex);

}