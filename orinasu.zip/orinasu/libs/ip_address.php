<?php
class ip_address{

	public $id;
	public $ip_address;

	public function get_ip_address(){
		return $this->ip_address;
	}


}