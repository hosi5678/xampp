<?php
class password{

	private $id;
	private $password;

	public function getPassword(){
		return $this->password;
	}


}