<?php
class ip_address{

	private $id;
	private $ip_address;

	public function get_ip_address(){
		return $this->ip_address;
	}


}