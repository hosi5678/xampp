<?php
// セッション処理開始
session_start();
session_regenerate_id();
