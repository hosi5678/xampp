<?php

ini_set('display_errors',1);

define('db_name','dotinstall_todo_app');
define('db_username','dbuser');
define('db_password','hosi3162');
define('pdo_dsn','mysql:dbhost=localhost;dbname='.db_name);