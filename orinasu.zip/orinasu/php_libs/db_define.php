<?php

define('db_name','orinasu_db');
define('db_username','root');
define('db_password','orinasu_admin');
define('pdo_dsn','mysql:dbhost=localhost;dbname='.db_name);
