<?php

require("../libs/session.php");
require("../libs/escape_string.php");
require("../libs/is_empty.php");

$id_ext=escape_string($_POST["id"]);
is_empty($id_ext);

$_SESSION["id"]=$id_ext;

	if($id_ext==='1'){
//		echo 'orinasu_admin';

		$links='<a href="../other_pages/select_users.php">ユーザ一覧</a>';

	}else if($id_ext==='2'){
		$links='<a href="../other_pages/select_users.php">棚卸し表</a>';
	}

?>

<!doctype html>

<html lang="ja">

<head>
<meta charset="utf-8">
<title>おりなすメインメニュー</title>
	<link rel="stylesheet" type="text/css" href="./css/menu.css">
	<link rel="stylesheet" type="text/css" href="../css/jquery-ui.min.css">
	<script type="text/javascript" src="../js/jquery-3.4.1.min.js"></script>
	<script type="text/javascript" src="../js/jquery-ui.min.js"></script>
</head>

<script type="text/javascript">

</script>

<body>

<!--
<div id='resizable' class="ui-widget-content">
-->

<header>ヘッダー</header>

	<nav>
		<article>リンク</article>
		<article><?php echo $links ?></article>
		<article>リンク2</article>
		<article>リンク3</article>
	</nav>

	<main>
		<article>main1</article>
		<article>main2</article>
		<article>main3</article>
	</main>

	<aside>
		<article>補足1</article>
		<article>補足2</article>
		<article>補足3</article>
	</aside>


	<footer>フッター</footer>

<!--
</div>
-->

</body>

</html>