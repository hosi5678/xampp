use mysql;
alter user 'root'@'localhost' identified BY 'hosi3162';